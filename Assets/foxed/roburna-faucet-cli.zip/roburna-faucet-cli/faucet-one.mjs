import fs from 'node:fs'
import {
  createPublicClient,
  defineChain,
  formatEther,
  http,
} from 'viem'
import { privateKeyToAccount } from 'viem/accounts'

const RPC_URL = 'https://preseed-testnet-1.roburna.com'
const FAUCET = 'https://faucet.roburna.com'
const WALLET_FILE = './wallets-unified.json'
const POLL_MS = 3000
const TIMEOUT_MS = 120000

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms))
}

const chain = defineChain({
  id: 159,
  name: 'Roburna Testnet',
  nativeCurrency: { name: 'RBAT', symbol: 'RBAT', decimals: 18 },
  rpcUrls: { default: { http: [RPC_URL] } },
})

const publicClient = createPublicClient({
  chain,
  transport: http(RPC_URL),
})

if (!fs.existsSync(WALLET_FILE)) {
  throw new Error('Missing wallets-unified.json. Generate wallets first from menu option 4.')
}

const wallets = JSON.parse(fs.readFileSync(WALLET_FILE, 'utf8'))
const wallet = wallets.find(
  w => w.status === 'available-for-future-testing' && w.privateKey
)

if (!wallet) throw new Error('No available wallet with a private key found.')

const account = privateKeyToAccount(wallet.privateKey)

console.log('\n==============================================')
console.log(' ROBURNA SINGLE WALLET FAUCET TEST')
console.log('==============================================')
console.log(`Wallet #: ${wallet.number}`)
console.log(`Address:  ${account.address}`)

const before = await publicClient.getBalance({ address: account.address })
console.log(`Before:   ${formatEther(before)} RBAT`)
console.log('\nRequesting challenge...')

const challengeResponse = await fetch(`${FAUCET}/api/faucet/challenge`, {
  method: 'POST',
  headers: {
    'content-type': 'application/json',
    'accept': 'application/json',
  },
  body: JSON.stringify({
    wallet_address: account.address.toLowerCase(),
    chain_id: 159,
  }),
})

const challengeText = await challengeResponse.text()
if (!challengeResponse.ok) {
  throw new Error(`Challenge HTTP ${challengeResponse.status}: ${challengeText}`)
}

const challenge = JSON.parse(challengeText)
console.log(`Challenge: ${challenge.challenge_id}`)
console.log('Signing message...')

const signature = await account.signMessage({ message: challenge.message })

console.log('Submitting claim...')

const claimResponse = await fetch(`${FAUCET}/api/faucet/claims`, {
  method: 'POST',
  headers: {
    'content-type': 'application/json',
    'accept': 'application/json',
  },
  body: JSON.stringify({
    challenge_id: challenge.challenge_id,
    chain_id: 159,
    wallet_address: account.address.toLowerCase(),
    message: challenge.message,
    signature,
  }),
})

const claimText = await claimResponse.text()
if (!claimResponse.ok) {
  throw new Error(`Claim HTTP ${claimResponse.status}: ${claimText}`)
}

const claim = JSON.parse(claimText)
console.log(`Claim ID: ${claim.claim_id}`)
console.log(`Initial status: ${claim.status}`)
console.log(`Amount: ${formatEther(BigInt(claim.amount_wei))} RBAT`)

const started = Date.now()
let finalBalance = before
let finalStatus = claim.status

while (Date.now() - started < TIMEOUT_MS) {
  await sleep(POLL_MS)

  finalBalance = await publicClient.getBalance({ address: account.address })
  const statusResponse = await fetch(`${FAUCET}/api/faucet/claims/${claim.claim_id}`)

  if (statusResponse.ok) {
    const status = await statusResponse.json()
    finalStatus = status.status
    console.log(`status=${finalStatus} balance=${formatEther(finalBalance)} RBAT`)

    if (finalStatus === 'failed') {
      throw new Error(`Claim failed: ${status.failure_code ?? 'unknown'}`)
    }
  } else {
    console.log(`status=? balance=${formatEther(finalBalance)} RBAT`)
  }

  if (finalBalance > before) break
}

if (finalBalance <= before) {
  throw new Error('Timed out waiting for faucet balance.')
}

console.log('\n==============================================')
console.log(' FAUCET SUCCESS')
console.log('==============================================')
console.log(`Wallet:   ${account.address}`)
console.log(`Before:   ${formatEther(before)} RBAT`)
console.log(`After:    ${formatEther(finalBalance)} RBAT`)
console.log(`Received: ${formatEther(finalBalance - before)} RBAT`)

const now = new Date()
const cooldownUntil = new Date(now.getTime() + 24 * 60 * 60 * 1000)

wallet.balanceWei = finalBalance.toString()
wallet.balanceRBAT = formatEther(finalBalance)
wallet.faucetUsed = true
wallet.status = 'cooldown'
wallet.cooldownStartedAt = now.toISOString()
wallet.cooldownUntil = cooldownUntil.toISOString()
wallet.lastClaimId = claim.claim_id

fs.writeFileSync(
  WALLET_FILE,
  JSON.stringify(wallets, null, 2) + '\n',
  { mode: 0o600 }
)

console.log(`\nMarked wallet ${wallet.number} as cooldown.`)
console.log(`Cooldown until: ${wallet.cooldownUntil}`)
console.log(`Updated: ${WALLET_FILE}`)
console.log('==============================================')
