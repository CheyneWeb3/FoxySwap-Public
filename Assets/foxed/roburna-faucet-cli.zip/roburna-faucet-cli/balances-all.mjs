import fs from 'node:fs'
import path from 'node:path'
import {
  createPublicClient,
  defineChain,
  formatEther,
  http,
} from 'viem'
import { privateKeyToAccount } from 'viem/accounts'

const RPC_URL = 'https://preseed-testnet-1.roburna.com'
const chain = defineChain({
  id: 159,
  name: 'Roburna Testnet',
  nativeCurrency: { name: 'RBAT', symbol: 'RBAT', decimals: 18 },
  rpcUrls: { default: { http: [RPC_URL] } },
})
const client = createPublicClient({ chain, transport: http(RPC_URL) })
const found = new Map()

function addWallet(address, source, privateKey = null) {
  const key = address.toLowerCase()
  if (!found.has(key)) {
    found.set(key, { address, sources: [], privateKey })
  }
  const entry = found.get(key)
  if (!entry.sources.includes(source)) entry.sources.push(source)
  if (!entry.privateKey && privateKey) entry.privateKey = privateKey
}

for (const file of [
  './wallets.json',
  './wallets20.json',
  './wallets-fresh.json',
  './wallets-unified.json',
]) {
  if (!fs.existsSync(file)) continue
  try {
    const wallets = JSON.parse(fs.readFileSync(file, 'utf8'))
    for (const wallet of wallets) {
      if (!wallet.address) continue
      addWallet(wallet.address, file, wallet.privateKey ?? null)
    }
  } catch (error) {
    console.log(`Could not read ${file}: ${error.message}`)
  }
}

const keyFiles = fs.readdirSync('.').filter(
  name => name === 'faucet-test.key' || /^wallet-.*\.key$/.test(name)
)

for (const name of keyFiles) {
  try {
    const privateKey = fs.readFileSync(path.join('.', name), 'utf8').trim()
    const account = privateKeyToAccount(privateKey)
    addWallet(account.address, `./${name}`, privateKey)
  } catch (error) {
    console.log(`Could not read ${name}: ${error.message}`)
  }
}

console.log('\n==============================================================')
console.log(' ALL SAVED ROBURNA WALLETS')
console.log('==============================================================\n')

let total = 0n
let funded = 0
let zero = 0
let number = 0

for (const wallet of found.values()) {
  number++
  try {
    const balance = await client.getBalance({ address: wallet.address })
    total += balance
    if (balance > 0n) funded++
    else zero++

    console.log(
      `${String(number).padStart(2, '0')}  ` +
      `${wallet.address}  ` +
      `${formatEther(balance).padStart(18)} RBAT`
    )
    console.log(`    source: ${wallet.sources.join(', ')}`)
  } catch (error) {
    console.log(`${String(number).padStart(2, '0')}  ${wallet.address}  ERROR`)
    console.log(`    ${error.shortMessage ?? error.message}`)
  }
}

console.log('\n==============================================================')
console.log(`Wallets found: ${found.size}`)
console.log(`Funded:        ${funded}`)
console.log(`Zero balance:  ${zero}`)
console.log(`TOTAL:         ${formatEther(total)} RBAT`)
console.log('==============================================================')
