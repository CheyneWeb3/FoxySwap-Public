import fs from 'node:fs'
import path from 'node:path'
import readline from 'node:readline/promises'
import { stdin as input, stdout as output } from 'node:process'
import {
  createPublicClient,
  createWalletClient,
  defineChain,
  formatEther,
  getAddress,
  http,
  isAddress,
} from 'viem'
import { privateKeyToAccount } from 'viem/accounts'

const RPC_URL = 'https://preseed-testnet-1.roburna.com'
const EXPLORER = 'https://testnet.rbascan.com'
const chain = defineChain({
  id: 159,
  name: 'Roburna Testnet',
  nativeCurrency: { name: 'RBAT', symbol: 'RBAT', decimals: 18 },
  rpcUrls: { default: { http: [RPC_URL] } },
})
const publicClient = createPublicClient({ chain, transport: http(RPC_URL) })
const rl = readline.createInterface({ input, output })

console.log('\n==============================================')
console.log(' ROBURNA — SWEEP ALL SAVED WALLETS')
console.log('==============================================\n')

const entered = (await rl.question('Paste destination wallet address: ')).trim()
if (!isAddress(entered)) {
  rl.close()
  throw new Error(`Invalid EVM address: ${entered}`)
}
const DESTINATION = getAddress(entered)

console.log(`\nDestination: ${DESTINATION}`)
const confirm = (await rl.question('Type YES to sweep all funded wallets: ')).trim()
rl.close()

if (confirm !== 'YES') {
  console.log('\nCancelled.')
  process.exit(0)
}

const wallets = new Map()

function addPrivateKey(privateKey, source) {
  try {
    const account = privateKeyToAccount(privateKey.trim())
    const key = account.address.toLowerCase()
    if (!wallets.has(key)) {
      wallets.set(key, {
        address: account.address,
        privateKey: privateKey.trim(),
        sources: [],
      })
    }
    const entry = wallets.get(key)
    if (source && !entry.sources.includes(source)) entry.sources.push(source)
  } catch {
    console.log(`Skipping invalid key from ${source}`)
  }
}

for (const file of [
  './wallets.json',
  './wallets20.json',
  './wallets-fresh.json',
  './wallets-unified.json',
]) {
  if (!fs.existsSync(file)) continue
  try {
    const entries = JSON.parse(fs.readFileSync(file, 'utf8'))
    for (const entry of entries) {
      if (entry.privateKey) addPrivateKey(entry.privateKey, file)
    }
  } catch (error) {
    console.log(`Could not read ${file}: ${error.message}`)
  }
}

for (const name of fs.readdirSync('.').filter(
  name => name === 'faucet-test.key' || /^wallet-.*\.key$/.test(name)
)) {
  try {
    addPrivateKey(
      fs.readFileSync(path.join('.', name), 'utf8').trim(),
      `./${name}`
    )
  } catch (error) {
    console.log(`Could not read ${name}: ${error.message}`)
  }
}

console.log(`\nUnique wallets with keys found: ${wallets.size}`)
console.log('\nChecking balances...')

const funded = []
let totalBefore = 0n

for (const wallet of wallets.values()) {
  if (wallet.address.toLowerCase() === DESTINATION.toLowerCase()) {
    console.log(`SKIP destination itself: ${wallet.address}`)
    continue
  }

  try {
    const balance = await publicClient.getBalance({ address: wallet.address })
    if (balance === 0n) continue
    totalBefore += balance
    funded.push({ ...wallet, balance })
    console.log(`${wallet.address}  ${formatEther(balance)} RBAT`)
  } catch {
    console.log(`Balance check failed: ${wallet.address}`)
  }
}

console.log('\n==============================================')
console.log(`Funded wallets: ${funded.length}`)
console.log(`Total held:     ${formatEther(totalBefore)} RBAT`)
console.log('==============================================')

if (funded.length === 0) {
  console.log('\nNo funded wallets found.')
  process.exit(0)
}

const destinationBefore = await publicClient.getBalance({ address: DESTINATION })
console.log(`\nDestination before: ${formatEther(destinationBefore)} RBAT`)

let submitted = 0
let failed = 0

for (let i = 0; i < funded.length; i++) {
  const wallet = funded[i]
  console.log('\n==============================================')
  console.log(` SWEEP ${i + 1}/${funded.length}`)
  console.log('==============================================')
  console.log(`From:    ${wallet.address}`)
  console.log(`Balance: ${formatEther(wallet.balance)} RBAT`)

  try {
    const account = privateKeyToAccount(wallet.privateKey)
    const walletClient = createWalletClient({
      account,
      chain,
      transport: http(RPC_URL),
    })

    const estimatedGas = await publicClient.estimateGas({
      account: account.address,
      to: DESTINATION,
      value: 1n,
    })
    const networkGasPrice = await publicClient.getGasPrice()
    const gasLimit = (estimatedGas * 120n) / 100n
    const gasPrice = (networkGasPrice * 125n) / 100n
    const maximumFee = gasLimit * gasPrice

    if (wallet.balance <= maximumFee) {
      throw new Error('Balance too low for gas.')
    }

    const amount = wallet.balance - maximumFee

    console.log(`Send:    ${formatEther(amount)} RBAT`)
    console.log(`Reserve: ${formatEther(maximumFee)} RBAT`)

    const hash = await walletClient.sendTransaction({
      account,
      to: DESTINATION,
      value: amount,
      gas: gasLimit,
      gasPrice,
    })

    console.log(`TX: ${hash}`)
    console.log(`${EXPLORER}/tx/${hash}`)
    submitted++
  } catch (error) {
    failed++
    console.log('FAILED')
    console.log(error.shortMessage ?? error.message ?? String(error))
  }
}

const destinationAfter = await publicClient.getBalance({ address: DESTINATION })

console.log('\n==============================================')
console.log(' SWEEP SUMMARY')
console.log('==============================================')
console.log(`Funded wallets:      ${funded.length}`)
console.log(`Submitted:           ${submitted}`)
console.log(`Failed:              ${failed}`)
console.log(`Destination before:  ${formatEther(destinationBefore)} RBAT`)
console.log(`Destination after:   ${formatEther(destinationAfter)} RBAT`)
console.log(`Destination:         ${DESTINATION}`)
console.log('==============================================')
