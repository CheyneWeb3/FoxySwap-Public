import { spawn } from 'node:child_process'
import readline from 'node:readline/promises'
import { stdin as input, stdout as output } from 'node:process'

const rl = readline.createInterface({ input, output })

function run(script) {
  return new Promise((resolve) => {
    const child = spawn(process.execPath, [script], { stdio: 'inherit' })
    child.on('exit', (code) => resolve(code ?? 1))
  })
}

while (true) {
  console.log(`
==============================================
 ROBURNA TESTNET CLI
==============================================
1) Faucet test — one available saved wallet
2) Show all saved wallet balances + totals
3) Sweep all funded saved wallets
4) Generate and add more test wallets
5) Exit
==============================================
`)
  const choice = (await rl.question('Choose 1-5: ')).trim()

  if (choice === '1') await run('faucet-one.mjs')
  else if (choice === '2') await run('balances-all.mjs')
  else if (choice === '3') await run('sweep-all.mjs')
  else if (choice === '4') await run('generate-wallets.mjs')
  else if (choice === '5') break
  else console.log('Invalid choice.')

  if (choice !== '5') {
    await rl.question('\nPress Enter to return to menu...')
  }
}

rl.close()
