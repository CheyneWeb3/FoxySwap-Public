import fs from 'node:fs'
import readline from 'node:readline/promises'
import { stdin as input, stdout as output } from 'node:process'
import { generatePrivateKey, privateKeyToAccount } from 'viem/accounts'

const WALLET_FILE = './wallets-unified.json'
const PUBLIC_FILE = './wallets-unified-public.json'
const rl = readline.createInterface({ input, output })

console.log('\n==============================================')
console.log(' GENERATE ADDITIONAL TEST WALLETS')
console.log('==============================================')

const rawCount = (await rl.question('How many wallets do you want to add? ')).trim()
const count = Number(rawCount)

if (!Number.isInteger(count) || count < 1 || count > 1000) {
  rl.close()
  throw new Error('Enter a whole number from 1 to 1000.')
}

let wallets = []
if (fs.existsSync(WALLET_FILE)) {
  wallets = JSON.parse(fs.readFileSync(WALLET_FILE, 'utf8'))
  if (!Array.isArray(wallets)) {
    rl.close()
    throw new Error(`${WALLET_FILE} is not a JSON array.`)
  }
}

const existing = new Set(
  wallets.filter(w => w?.address).map(w => w.address.toLowerCase())
)

let nextNumber = wallets.reduce(
  (max, w) => Number.isInteger(w?.number) ? Math.max(max, w.number) : max,
  0
) + 1

const created = []

while (created.length < count) {
  const privateKey = generatePrivateKey()
  const account = privateKeyToAccount(privateKey)
  const lower = account.address.toLowerCase()
  if (existing.has(lower)) continue

  const entry = {
    number: nextNumber++,
    address: account.address,
    privateKey,
    balanceWei: '0',
    balanceRBAT: '0',
    faucetUsed: false,
    status: 'available-for-future-testing',
    cooldownStartedAt: null,
    cooldownUntil: null,
    lastClaimId: null,
    sources: ['./wallets-unified.json'],
    createdAt: new Date().toISOString()
  }

  wallets.push(entry)
  created.push(entry)
  existing.add(lower)
}

fs.writeFileSync(
  WALLET_FILE,
  JSON.stringify(wallets, null, 2) + '\n',
  { mode: 0o600 }
)

const publicWallets = wallets.map(({ privateKey, ...wallet }) => wallet)
fs.writeFileSync(
  PUBLIC_FILE,
  JSON.stringify(publicWallets, null, 2) + '\n',
  { mode: 0o644 }
)

console.log(`\nAdded ${created.length} wallets.`)
console.log(`Private registry: ${WALLET_FILE}`)
console.log(`Public registry:  ${PUBLIC_FILE}\n`)

for (const wallet of created) {
  console.log(`${String(wallet.number).padStart(3, '0')}  ${wallet.address}`)
}

console.log(`\nTotal wallets now: ${wallets.length}`)
console.log('\nKeep wallets-unified.json private: it contains the private keys.')
rl.close()
