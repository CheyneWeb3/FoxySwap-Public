import { spawn } from 'node:child_process'
import readline from 'node:readline/promises'
import {
  stdin as input,
  stdout as output,
} from 'node:process'

function makeReadline() {
  return readline.createInterface({ input, output })
}

function run(script) {
  return new Promise((resolve) => {
    const child = spawn(process.execPath, [script], {
      stdio: 'inherit',
    })

    child.on('exit', code => resolve(code ?? 1))
  })
}

while (true) {
  let rl = makeReadline()

  console.log(`
==============================================
 ROBURNA TESTNET CLI
==============================================
1) Faucet test — one available saved wallet
2) Show all saved wallet balances + totals
3) Sweep all funded saved wallets
4) Generate and add more test wallets
5) Exit
==============================================
`)

  const choice = (await rl.question('Choose 1-5: ')).trim()

  if (choice === '5') {
    rl.close()
    break
  }

  let script = null

  if (choice === '1') script = 'faucet-one.mjs'
  else if (choice === '2') script = 'balances-all.mjs'
  else if (choice === '3') script = 'sweep-all.mjs'
  else if (choice === '4') script = 'generate-wallets.mjs'
  else {
    console.log('Invalid choice.')
    await rl.question('\nPress Enter to continue...')
    rl.close()
    continue
  }

  // Close the parent menu reader before the child command uses stdin.
  rl.close()

  await run(script)

  // Re-open stdin only after the child exits.
  rl = makeReadline()
  await rl.question('\nPress Enter to return to menu...')
  rl.close()
}
