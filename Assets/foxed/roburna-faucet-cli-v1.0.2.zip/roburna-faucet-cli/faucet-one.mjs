import fs from 'node:fs'
import {
  createPublicClient,
  defineChain,
  formatEther,
  http,
} from 'viem'
import { privateKeyToAccount } from 'viem/accounts'

const RPC_URL = 'https://preseed-testnet-1.roburna.com'
const FAUCET = 'https://faucet.roburna.com'
const WALLET_FILE = './wallets-unified.json'
const POLL_MS = 3000
const TIMEOUT_MS = 120000

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms))
}

function saveWallets(wallets) {
  fs.writeFileSync(
    WALLET_FILE,
    JSON.stringify(wallets, null, 2) + '\n',
    { mode: 0o600 }
  )
}

function getErrorCode(text) {
  try {
    const parsed = JSON.parse(text)
    return parsed?.detail?.code ?? parsed?.code ?? null
  } catch {
    return null
  }
}

const chain = defineChain({
  id: 159,
  name: 'Roburna Testnet',
  nativeCurrency: { name: 'RBAT', symbol: 'RBAT', decimals: 18 },
  rpcUrls: { default: { http: [RPC_URL] } },
})

const publicClient = createPublicClient({
  chain,
  transport: http(RPC_URL),
})

if (!fs.existsSync(WALLET_FILE)) {
  throw new Error('Missing wallets-unified.json. Generate wallets first from menu option 4.')
}

const wallets = JSON.parse(fs.readFileSync(WALLET_FILE, 'utf8'))
if (!Array.isArray(wallets)) {
  throw new Error(`${WALLET_FILE} is not a JSON array.`)
}

const candidates = wallets.filter(
  wallet =>
    wallet.status === 'available-for-future-testing' &&
    wallet.privateKey
)

if (candidates.length === 0) {
  console.log(`
==============================================
 NO AVAILABLE SAVED WALLETS
==============================================
No wallets marked available-for-future-testing.

Generate more wallets with menu option 4.
==============================================
`)
  process.exit(0)
}

console.log(`
==============================================
 ROBURNA SINGLE WALLET FAUCET TEST
==============================================
Checking ${candidates.length} available saved wallet(s)...
`)

const liveCandidates = []

for (const wallet of candidates) {
  const account = privateKeyToAccount(wallet.privateKey)

  let balance
  try {
    balance = await publicClient.getBalance({ address: account.address })
  } catch (error) {
    console.log(
      `Wallet #${wallet.number}: balance lookup failed — ${error.shortMessage ?? error.message ?? String(error)}`
    )
    continue
  }

  const balanceWei = balance.toString()

  if (
    wallet.faucetBlockedReason === 'recipient_balance_limit_exceeded' &&
    wallet.faucetBlockedAtBalanceWei === balanceWei
  ) {
    console.log(
      `Wallet #${wallet.number}: ${formatEther(balance)} RBAT — skipped (recipient balance limit)`
    )
    continue
  }

  if (wallet.faucetBlockedReason === 'recipient_balance_limit_exceeded') {
    delete wallet.faucetBlockedReason
    delete wallet.faucetBlockedAt
    delete wallet.faucetBlockedAtBalanceWei
    delete wallet.faucetBlockedAtBalanceRBAT
    saveWallets(wallets)
  }

  liveCandidates.push({ wallet, account, balance })
}

liveCandidates.sort((a, b) => {
  if (a.balance < b.balance) return -1
  if (a.balance > b.balance) return 1
  return 0
})

if (liveCandidates.length === 0) {
  console.log(`
==============================================
 NO FAUCET-ELIGIBLE SAVED WALLET FOUND
==============================================
Every available wallet has already been rejected
by the faucet because of the recipient balance limit.

Use menu option 3 to sweep funded wallets,
or menu option 4 to generate additional wallets.
==============================================
`)
  process.exit(0)
}

let faucetSucceeded = false

for (const candidate of liveCandidates) {
  const { wallet, account, balance: before } = candidate

  console.log('\n----------------------------------------------')
  console.log(`Trying wallet #: ${wallet.number}`)
  console.log(`Address:         ${account.address}`)
  console.log(`Before:          ${formatEther(before)} RBAT`)
  console.log('----------------------------------------------')
  console.log('Requesting challenge...')

  const challengeResponse = await fetch(`${FAUCET}/api/faucet/challenge`, {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      'accept': 'application/json',
    },
    body: JSON.stringify({
      wallet_address: account.address.toLowerCase(),
      chain_id: 159,
    }),
  })

  const challengeText = await challengeResponse.text()
  if (!challengeResponse.ok) {
    const code = getErrorCode(challengeText)

    if (code === 'recipient_balance_limit_exceeded') {
      console.log(
        `SKIP: Wallet #${wallet.number} rejected — recipient balance limit exceeded.`
      )
      wallet.faucetBlockedReason = 'recipient_balance_limit_exceeded'
      wallet.faucetBlockedAt = new Date().toISOString()
      wallet.faucetBlockedAtBalanceWei = before.toString()
      wallet.faucetBlockedAtBalanceRBAT = formatEther(before)
      saveWallets(wallets)
      console.log('Trying next available wallet...')
      continue
    }

    throw new Error(`Challenge HTTP ${challengeResponse.status}: ${challengeText}`)
  }

  const challenge = JSON.parse(challengeText)
  console.log(`Challenge: ${challenge.challenge_id}`)
  console.log('Signing message...')

  const signature = await account.signMessage({ message: challenge.message })

  console.log('Submitting claim...')

  const claimResponse = await fetch(`${FAUCET}/api/faucet/claims`, {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      'accept': 'application/json',
    },
    body: JSON.stringify({
      challenge_id: challenge.challenge_id,
      chain_id: 159,
      wallet_address: account.address.toLowerCase(),
      message: challenge.message,
      signature,
    }),
  })

  const claimText = await claimResponse.text()
  if (!claimResponse.ok) {
    const code = getErrorCode(claimText)

    if (code === 'recipient_balance_limit_exceeded') {
      console.log(
        `SKIP: Wallet #${wallet.number} rejected — recipient balance limit exceeded.`
      )
      wallet.faucetBlockedReason = 'recipient_balance_limit_exceeded'
      wallet.faucetBlockedAt = new Date().toISOString()
      wallet.faucetBlockedAtBalanceWei = before.toString()
      wallet.faucetBlockedAtBalanceRBAT = formatEther(before)
      saveWallets(wallets)
      console.log('Trying next available wallet...')
      continue
    }

    throw new Error(`Claim HTTP ${claimResponse.status}: ${claimText}`)
  }

  const claim = JSON.parse(claimText)
  console.log(`Claim ID: ${claim.claim_id}`)
  console.log(`Initial status: ${claim.status}`)
  console.log(`Amount: ${formatEther(BigInt(claim.amount_wei))} RBAT`)

  const started = Date.now()
  let finalBalance = before
  let finalStatus = claim.status

  while (Date.now() - started < TIMEOUT_MS) {
    await sleep(POLL_MS)

    finalBalance = await publicClient.getBalance({ address: account.address })
    const statusResponse = await fetch(
      `${FAUCET}/api/faucet/claims/${claim.claim_id}`
    )

    if (statusResponse.ok) {
      const status = await statusResponse.json()
      finalStatus = status.status
      console.log(`status=${finalStatus} balance=${formatEther(finalBalance)} RBAT`)

      if (finalStatus === 'failed') {
        throw new Error(`Claim failed: ${status.failure_code ?? 'unknown'}`)
      }
    } else {
      console.log(`status=? balance=${formatEther(finalBalance)} RBAT`)
    }

    if (finalBalance > before) break
  }

  if (finalBalance <= before) {
    throw new Error('Timed out waiting for faucet balance.')
  }

  console.log(`
==============================================
 FAUCET SUCCESS
==============================================`)
  console.log(`Wallet #: ${wallet.number}`)
  console.log(`Wallet:   ${account.address}`)
  console.log(`Before:   ${formatEther(before)} RBAT`)
  console.log(`After:    ${formatEther(finalBalance)} RBAT`)
  console.log(`Received: ${formatEther(finalBalance - before)} RBAT`)

  const now = new Date()
  const cooldownUntil = new Date(now.getTime() + 24 * 60 * 60 * 1000)

  wallet.balanceWei = finalBalance.toString()
  wallet.balanceRBAT = formatEther(finalBalance)
  wallet.faucetUsed = true
  wallet.status = 'cooldown'
  wallet.cooldownStartedAt = now.toISOString()
  wallet.cooldownUntil = cooldownUntil.toISOString()
  wallet.lastClaimId = claim.claim_id

  delete wallet.faucetBlockedReason
  delete wallet.faucetBlockedAt
  delete wallet.faucetBlockedAtBalanceWei
  delete wallet.faucetBlockedAtBalanceRBAT

  saveWallets(wallets)

  console.log(`\nMarked wallet ${wallet.number} as cooldown.`)
  console.log(`Cooldown until: ${wallet.cooldownUntil}`)
  console.log(`Updated: ${WALLET_FILE}`)
  console.log('==============================================')

  faucetSucceeded = true
  break
}

if (!faucetSucceeded) {
  console.log(`
==============================================
 NO FAUCET-ELIGIBLE WALLET FOUND
==============================================
Roburna rejected every candidate because of
the recipient balance limit.

The rejected balances have been recorded.
Next run will skip those wallets automatically
unless their balances have changed.

Use:
  3) Sweep all funded saved wallets

or:
  4) Generate and add more test wallets
==============================================
`)
}
